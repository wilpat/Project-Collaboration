<?php

namespace App\Http\Controllers;

use App\Project;
use App\Http\Requests\UpdateProjectRequest;
use Illuminate\Http\Request;

class ProjectController extends Controller
{   

    /**
     * Validate the request attributes
     *
     * @return array
     */
    protected function validateProject(){

        return request()->validate([
            'title' => 'sometimes|required | min:3 | max:255',
            'description' => 'sometimes|required | min:3 | max:100',
            'notes' => 'nullable',
        ]);

    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // dd(auth()->id());
        // $projects = Project::all();
        $projects = auth()->user()->accessibleProjects();
        // dd($projects);
        return $projects;
        // return view('projects.index', compact('projects'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('projects.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $attributes = $this->validateProject();
        $project = auth()->user()->projects()->create($attributes);
        return $project;
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Project  $project
     * @return \Illuminate\Http\Response
     */
    public function show(Project $project)
    {   
        $this->authorize('update', $project);
        return $project->with('tasks','users','user','activities.user', 'activities.subject')->get()[0];
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Project  $project
     * @return \Illuminate\Http\Response
     */
    public function edit(Project $project)
    {
        return view('projects.edit', compact('project'));
    }

    /**
     * Update the project
     *
     * @param  \App\Requests\UpdateProjectRequest  $request - Form request
     * @param  Project                             $project
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(UpdateProjectRequest $request, Project $project)
    {   
        // Now the update happens with the save method of the UpdateProjectRequest form request handler
        $request->save();
        return $project;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Project  $project
     * @return \Illuminate\Http\Response
     */
    public function destroy(Project $project)
    {
        $this->authorize('manage', $project); // A Policy
        $project->delete();
        return $project;
    }
}
