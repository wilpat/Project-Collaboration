<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div>

                <div>
                    <form 
                        method="POST" 
                        action="<?php echo e(route('register')); ?>"
                        class="lg:w-1/2 lg:mx-auto bg-white p-6 md:py-12 md:px-12 md:px-16 rounded shadow mt-6"
                    >
                        <?php echo csrf_field(); ?>
                        <h1 class="text-2xl font-normal mb-10 text-center">
                            <?php echo e(__('Register')); ?>

                        </h1>

                        <div class="field mb-6">
                            <label for="name" class="label text-sm mb-2 block"><?php echo e(__('Name')); ?></label>

                            <div class="control">
                                <input 
                                    id="name" 
                                    type="text" 
                                    class="input bg-transparent border border-grey-light rounded p-2 text-ws w-full<?php echo e($errors->has('name') ? ' border-red' : ''); ?>" 
                                    name="name" 
                                    value="<?php echo e(old('name')); ?>" 
                                    required 
                                    autofocus
                                >

                                <?php if($errors->has('name')): ?>
                                    <span class="text-red text-xs italic" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="field mb-6">
                            <label for="email" class="label text-sm mb-2 block"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="control">
                                <input 
                                    id="email" 
                                    type="email" 
                                    class="input bg-transparent border border-grey-light rounded p-2 text-ws w-full<?php echo e($errors->has('email') ? ' border-red' : ''); ?>" 
                                    name="email" 
                                    value="<?php echo e(old('email')); ?>" 
                                    required
                                >

                                <?php if($errors->has('email')): ?>
                                    <span class="text-red text-xs italic" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="field mb-6">
                            <label for="password" class="label text-sm mb-2 block"><?php echo e(__('Password')); ?></label>

                            <div class="control">
                                <input 
                                    id="password" 
                                    type="password" 
                                    class="input bg-transparent border border-grey-light rounded p-2 text-ws w-full<?php echo e($errors->has('password') ? ' border-red' : ''); ?>" 
                                    name="password" 
                                    required
                                >

                                <?php if($errors->has('password')): ?>
                                    <span class="text-red text-xs italic" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="field mb-6">
                            <label for="password-confirm" class="label text-sm mb-2 block"><?php echo e(__('Confirm Password')); ?></label>

                            <div class="control">
                                <input 
                                    id="password-confirm" 
                                    type="password" 
                                    class="input bg-transparent border border-grey-light rounded p-2 text-ws w-full" 
                                    name="password_confirmation" 
                                    required
                                >
                            </div>
                        </div>

                        <div class="text-center">
                            <button type="submit" class="button">
                                <?php echo e(__('Register')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/william/Documents/Projects/Laravel/Project-Collaboration/resources/views/auth/register.blade.php ENDPATH**/ ?>