<?php $__env->startSection('content'); ?>

<form 
	method="POST" 
	action="/projects"
	class="lg:w-1/2 lg:mx-auto bg-white p-6 md:py-12 md:px-12 md:px-16 rounded shadow mt-6" 
>
	<h1 class="text-2xl font-normal mb-10 text-center">
		Let's start something new
	</h1>
	<?php echo $__env->make('projects.form',[
			'project' => new App\Project,
			'buttonText' => 'Create Project'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/william/Documents/Projects/Laravel/Project-Collaboration/resources/views/projects/create.blade.php ENDPATH**/ ?>