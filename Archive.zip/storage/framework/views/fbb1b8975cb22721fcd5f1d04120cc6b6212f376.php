<?php if($errors->{$bag ?? 'default'}->any()): ?>
    <ul class="field mt-6 list-reset">
        <?php $__currentLoopData = $errors->{$bag ?? 'default'}->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="text-sm text-red"><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?><?php /**PATH /Users/william/Documents/Projects/Laravel/Project-Collaboration/resources/views/errors.blade.php ENDPATH**/ ?>