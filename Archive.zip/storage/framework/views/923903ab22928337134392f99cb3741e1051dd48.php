<div class="card flex flex-col" style="height: 200px">
	<h3 class="font-normal text-xl py-6 border-l-4 border-blue-light -ml-5 pl-4">
		<a href="<?php echo e($project->path()); ?>" class="text-black no-underline">
			<?php echo e($project->title); ?>

		</a>
	</h3>
	<div class="text-grey flex-1">
		<?php echo e(str_limit($project->description, 100 )); ?>

	</div>
	<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage', $project)): ?>
		<footer>
			<form method="POST" action="<?php echo e($project->path()); ?>" class="text-right">
				<?php echo method_field('DELETE'); ?>
				<?php echo csrf_field(); ?>
				<button class="text-xs" type="submit">
					Delete
				</button>
			</form>
		</footer>
	<?php endif; ?>
</div><?php /**PATH /Users/william/Documents/Projects/Laravel/Project-Collaboration/resources/views/projects/card.blade.php ENDPATH**/ ?>