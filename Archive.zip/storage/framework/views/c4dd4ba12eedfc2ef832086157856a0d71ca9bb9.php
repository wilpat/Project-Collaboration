<div class="card mt-3">
	<ul class="text-sm list-reset">
		<?php $__currentLoopData = $project->activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li class="<?php echo e($loop->last ? '' : 'mb-1'); ?>"> 
				<?php echo $__env->make("projects.activity.{$activity->description}", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<span class="text-grey"><?php echo e($activity->created_at->diffForHumans(null, true)); ?></span>
			</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
</div><?php /**PATH /Users/william/Documents/Projects/Laravel/Project-Collaboration/resources/views/projects/activity/card.blade.php ENDPATH**/ ?>