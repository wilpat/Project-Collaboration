<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div>

                <div>
                    <form 
                        method="POST"
                        action="<?php echo e(route('login')); ?>"
                        class="lg:w-1/2 lg:mx-auto bg-white p-6 md:py-12 md:px-12 md:px-16 rounded shadow mt-6"
                    >
                        <h1 class="text-2xl font-normal mb-10 text-center">
                            <?php echo e(__('Login')); ?>

                        </h1>
                        <?php echo csrf_field(); ?>

                        <div class="field mb-6">
                            <label for="email" class="label text-sm mb-2 block"><?php echo e(__('E-Mail Address')); ?></label>

                            <div class="control">
                                <input 
                                    id="email" 
                                    type="email" 
                                    class="input bg-transparent border border-grey-light rounded p-2 text-ws w-full<?php echo e($errors->has('email') ? ' border-red' : ''); ?>" 
                                    name="email" 
                                    value="<?php echo e(old('email')); ?>" 
                                    required autofocus
                                >

                                <?php if($errors->has('email')): ?>
                                    <span class="text-red text-xs italic" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="field mb-6">
                            <label for="password" class="label text-sm mb-2 block"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input 
                                    id="password" 
                                    type="password" 
                                    class="input bg-transparent border border-grey-light rounded p-2 text-ws w-full<?php echo e($errors->has('password') ? ' border-red' : ''); ?>" 
                                    name="password" 
                                    required
                                >

                                <?php if($errors->has('password')): ?>
                                    <span class="text-red text-xs italic" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="mb-6">
                            <input class="" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                            <label class="label text-sm mb-2" for="remember">
                                <?php echo e(__('Remember Me')); ?>

                            </label>
                        </div>

                        <div class="flex items-center justify-between">
                            <button type="submit" class="button">
                                <?php echo e(__('Login')); ?>

                            </button>

                            <?php if(Route::has('password.request')): ?>
                                <a class="no-underline" href="<?php echo e(route('password.request')); ?>">
                                    <?php echo e(__('Forgot Your Password?')); ?>

                                </a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/william/Documents/Projects/Laravel/Project-Collaboration/resources/views/auth/login.blade.php ENDPATH**/ ?>