<?php echo csrf_field(); ?>

<div class="field mb-6">
  <label class="label text-sm mb-2 block" title="title">Title:</label>

  <div class="control">

    <input 
    	class="input bg-transparent border border-grey-light rounded p-2 text-ws w-full" 
    	type="text" 
    	placeholder="My next awesome project" 
    	name="title"
    	value="<?php echo e($project->title); ?>"
    	required 
    	>
  </div>
</div>


<div class="field">
  <label class="description">Description:</label>
  <div class="control">
	<textarea 
	class="textarea bg-transparent border border-grey-light rounded p-2 text-ws w-full"
	placeholder=""
	name="description"
	style="min-height: 200px"
	required><?php echo e($project->description); ?></textarea>
  </div>
</div>

<div class="field">
  	<div class="control">
	  <button class="button is-primary"><?php echo e($buttonText); ?></button>
	  <a href="<?php echo e($project->path()); ?>">Cancel</a>
	</div>
</div>

<?php if($errors->any()): ?>
	<div class="field mt-6">
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li class="text-sm text-red"><?php echo e($error); ?></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
<?php endif; ?><?php /**PATH /Users/william/Documents/Projects/Laravel/Project-Collaboration/resources/views/projects/form.blade.php ENDPATH**/ ?>