<?php $__env->startSection('title'); ?>
<?php echo e($project->title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	
	<header class="py-4">

		<div class="flex items-end justify-between">
			
			<p class="text-grey text-sm font-normal">
				<a href="/projects" class="no-underline text-grey">My Projects</a> / <?php echo e($project->title); ?>

			</p>

			<div class="flex items-center">
				<?php $__currentLoopData = $project->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<img 
					src="<?php echo e(gravatar_url($user->email)); ?>" 
					alt="<?php echo e($user->name); ?>"
					class="rounded-full w-8 mr-2">
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				<img 
					src="<?php echo e(gravatar_url($project->user->email)); ?>" 
					alt="<?php echo e($project->user->name); ?>"
					class="rounded-full w-8 mr-2">
				<a href="/projects/<?php echo e($project->id); ?>/edit" class="button ml-4">Edit Project</a>
			</div>
		</div>

	</header>

	<main>
		<div class="lg:flex -mx-3">
			<div class="lg:w-3/4 px-3">
				<div class="mb-8">

					<h2 class="text-grey font-normal text-lg mb-3">Tasks</h2>

					<?php $__currentLoopData = $project->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="card mb-3">
							<form action="<?php echo e($task->path()); ?>" method="POST">
								<?php echo method_field('PATCH'); ?>
								<?php echo csrf_field(); ?>
								<div class="flex">
									<input class="w-full <?php echo e($task->completed ? 'text-grey' : ''); ?>" type="text" name="body" value="<?php echo e($task->body); ?>" /> 
									<input type="checkbox" name="completed" onchange="this.form.submit()" <?php echo e($task->completed ? 'checked' : ''); ?>/>
								</div>

							</form>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					<form action="<?php echo e($project->path() . '/tasks'); ?>" method="POST">
						<?php echo csrf_field(); ?>
						<input class="card mb-3 w-full" type="text" placeholder="Add a new task..." name="body">
					</form>

				</div>
				<div class="mb-3">
					<h2 class="text-grey font-normal text-lg mb-3">General Notes</h2>
					<form action="<?php echo e($project->path()); ?>" method="POST">
						<?php echo csrf_field(); ?>
						<?php echo method_field('PATCH'); ?>
						<textarea name ="notes" class="card w-full" style="min-height: 200px" placeholder="Anything special you want to take note of?"><?php echo e($project->notes); ?></textarea>
						<input type="submit" class="button">
						<?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</form>
					
				</div>

			</div>

			<div class="lg:w-1/4 px-3">

				<?php echo $__env->make('projects.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php echo $__env->make('projects.activity.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage', $project)): ?>
					<?php echo $__env->make('projects.invite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php endif; ?>


			</div>
		</div>
	</main>
	
		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/william/Documents/Projects/Laravel/Project-Collaboration/resources/views/projects/show.blade.php ENDPATH**/ ?>